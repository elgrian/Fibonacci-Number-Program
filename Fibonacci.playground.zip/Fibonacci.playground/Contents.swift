func fibo(n: Int) -> [Int] {
    
    var array = [0, 1]
    //Calculation for Loop
    for _ in 0...n {
        array.append(array[array.count - 1] + array[array.count - 2])
    }
    return array
}
print(fibo(n: 90))

